import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useOfferto } from '../context/OffertoContext';
import StartScreen from '../screens/Core/StartScreen';
import ArchiefScreen from '../screens/Core/ArchiefScreen';
import InstellingenScreen from '../screens/Core/InstellingenScreen';
import WizardNavigator from './WizardNavigator';
import LoginScreen from '../screens/Auth/LoginScreen';
import SignUpScreen from '../screens/Auth/SignUpScreen';
import ProfielWizard from '../screens/Setup/ProfielWizard';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ActivityIndicator, Text } from 'react-native';

const Stack = createNativeStackNavigator();

export default function RootNavigator(){
  const { booting, user } = useOfferto();
  if (booting) return <SafeAreaView style={{flex:1,justifyContent:'center',alignItems:'center'}}><ActivityIndicator/><Text>Laden…</Text></SafeAreaView>;
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerBackTitleVisible:false }}>
        {!user ? (
          <>
            <Stack.Screen name="SignUp" component={SignUpScreen} options={{ title:'Account aanmaken' }} />
            <Stack.Screen name="Login" component={LoginScreen} options={{ title:'Inloggen' }} />
            <Stack.Screen name="ProfielWizard" component={ProfielWizard} options={{ title:'Bedrijfsprofiel' }} />
          </>
        ) : (
          <>
            <Stack.Screen name="Start" component={StartScreen} options={{ title:'Offerto' }} />
            <Stack.Screen name="Wizard" component={WizardNavigator} options={{ title:'Maak offerte' }} />
            <Stack.Screen name="Archief" component={ArchiefScreen} />
            <Stack.Screen name="Instellingen" component={InstellingenScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
