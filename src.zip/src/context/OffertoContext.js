import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Optioneel Supabase (uit in Snack/standaard)
const USE_SUPABASE = false; // zet true in echte app
const SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co';
const SUPABASE_ANON = 'YOUR_ANON_KEY';
let supabase = null;
try { if (USE_SUPABASE) { const { createClient } = require('@supabase/supabase-js'); supabase = createClient(SUPABASE_URL, SUPABASE_ANON, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } }); } } catch {}

export const DOC_STATUS = ['Concept','Verzonden','Bekeken','Getekend/Goedgekeurd','Betaald','Geannuleerd'];
export const STORAGE = { user: 'offerto.user', archive: 'offerto.archive', counters: 'offerto.counters' };

const OffertoContext = createContext(null);
export const useOfferto = () => useContext(OffertoContext);

const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const parseNum = (v) => { const n = parseFloat(String(v ?? '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };
const yearNow = () => new Date().getFullYear();

export function OffertoProvider({ children }) {
  const [booting, setBooting] = useState(true);
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState({ bedrijfsnaam: '', adres: '', postcode: '', stad: '', land: 'België', btwNummer: '', email: '', telefoon: '', iban: '', bic: '', bank: '', betalingsTermijn: '14 dagen', logoUrl: '', offerteGeldigheidDagen: 30, voorwaarden: '' });
  const [klant, setKlant] = useState({ bedrijfsnaam: '', contactpersoon: '', email: '', telefoon: '', adres: '', btwNummer: '', btwTariefDefault: 21 });
  const [onderdelen, setOnderdelen] = useState([]);
  const [docType, setDocType] = useState('OFFERTE');
  const [docNummer, setDocNummer] = useState('');
  const [docDatum, setDocDatum] = useState(new Date().toISOString().slice(0,10));
  const [signRequested, setSignRequested] = useState(false);
  const [archive, setArchive] = useState([]);
  const [statusFilter, setStatusFilter] = useState('ALLE');
  const [reminderPrefs, setReminderPrefs] = useState({ daysUntilReminder: 7 });

  useEffect(()=>{(async()=>{
    try{
      if (supabase) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          setUser({ id: session.user.id, email: session.user.email, name: session.user.email?.split('@')[0] });
          await refreshArchive(session.user.id);
        } else {
          const u = await AsyncStorage.getItem(STORAGE.user); if (u) setUser(JSON.parse(u));
        }
        supabase.auth.onAuthStateChange(async (_evt, sess)=>{
          if (sess?.user) {
            setUser({ id: sess.user.id, email: sess.user.email, name: sess.user.email?.split('@')[0] });
            await refreshArchive(sess.user.id);
          } else { setUser(null); setArchive([]); }
        });
      } else {
        const u = await AsyncStorage.getItem(STORAGE.user); if (u) setUser(JSON.parse(u));
        const a = await AsyncStorage.getItem(STORAGE.archive); if (a) setArchive(JSON.parse(a));
      }
    } finally { setBooting(false); }
  })()},[]);

  const addOnderdeel = (i)=>setOnderdelen(p=>[...p,{id:Date.now().toString(),...i}]);
  const removeOnderdeel = (id)=>setOnderdelen(p=>p.filter(r=>r.id!==id));

  const totals = useMemo(()=>{
    const lines=onderdelen.map(r=>{
      const qty=r.eenheid==='forfait'?1:parseNum(r.aantal);
      const up=round2(parseNum(r.eenheidsprijs));
      const ex=round2(qty*up);
      const btwA=round2(ex*(parseNum(r.btwPerc)/100));
      return {...r,aantal:qty,ex,btwA,inc:round2(ex+btwA)};
    });
    const exTotal=round2(lines.reduce((s,r)=>s+r.ex,0));
    const btwTotal=round2(lines.reduce((s,r)=>s+r.btwA,0));
    const incTotal=round2(exTotal+btwTotal);
    return{lines,exTotal,btwTotal,incTotal};
  },[onderdelen]);

  async function nextDocNumber(type){
    const y = String(yearNow());
    const prefix = type==='FACTUUR' ? 'INV' : 'Q';
    let counters = {};
    try{ const raw = await AsyncStorage.getItem(STORAGE.counters); if (raw) counters = JSON.parse(raw)||{}; }catch{}
    counters[y] = counters[y] || { INV: 0, Q: 0 };
    counters[y][prefix] = (counters[y][prefix]||0) + 1;
    await AsyncStorage.setItem(STORAGE.counters, JSON.stringify(counters));
    const seq = String(counters[y][prefix]).padStart(4,'0');
    return `${prefix}-${y}-${seq}`;
  }
  async function regenerateNumberFor(type){ const num = await nextDocNumber(type); setDocNummer(num); }

  async function signUp(email,password,name){
    if (supabase) {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) throw error; setUser({ id: data.user.id, email, name: name||email.split('@')[0] });
    } else {
      setUser({ email, name: name||email.split('@')[0] });
      await AsyncStorage.setItem(STORAGE.user, JSON.stringify({ email, name: name||email.split('@')[0] }));
    }
  }
  async function signIn(email,password){
    if (supabase) {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error; setUser({ id: data.user.id, email, name: email.split('@')[0] });
    } else {
      setUser({ email, name: email.split('@')[0] });
      await AsyncStorage.setItem(STORAGE.user, JSON.stringify({ email, name: email.split('@')[0] }));
    }
  }
  async function signOutAll(){ if (supabase) await supabase.auth.signOut(); setUser(null); await AsyncStorage.removeItem(STORAGE.user); }

  async function refreshArchive(uid){
    if (supabase && uid) {
      const { data, error } = await supabase.from('documents').select('id,type,number,date,total_incl,status,share_url,last_reminder_at').order('date', { ascending:false });
      if (!error && data) setArchive(data.map(d=>({ id:d.id, type:d.type, number:d.number, date:d.date, total:d.total_incl, status:d.status||'Concept', shareUrl:d.share_url, lastReminderAt:d.last_reminder_at })));
    } else {
      const a = await AsyncStorage.getItem(STORAGE.archive); if (a) setArchive(JSON.parse(a));
    }
  }

  async function saveToArchive(doc){
    if (supabase && user?.id) {
      const { type, number, date, totals, lines, signRequested } = doc;
      const { data: inserted, error: e1 } = await supabase
        .from('documents')
        .insert([{ user_id: user.id, type, number, date, total_excl: totals.exTotal, total_vat: totals.btwTotal, total_incl: totals.incTotal, sign_requested: !!signRequested, status: 'Concept', last_reminder_at: null }])
        .select().single();
      if (e1) throw e1;
      const rows = (lines||[]).map((l,i)=>({ document_id: inserted.id, description: l.omschrijving, qty: l.eenheid==='forfait'?1:Number(l.aantal||1), unit: l.eenheid, unit_price: Number(l.eenheidsprijs||0), vat_rate: Number(l.btwPerc||21), line_excl: Number(l.ex||0), line_vat: Number(l.btwA||0), line_incl: Number(l.inc||0), position: i+1 }));
      if (rows.length) { const { error: e2 } = await supabase.from('document_lines').insert(rows); if (e2) throw e2; }
      await refreshArchive(user.id);
    } else {
      const item = { id: Date.now().toString(), type: doc.type, number: doc.number, date: doc.date, total: doc.totals?.incTotal ?? 0, signRequested: !!doc.signRequested, status: 'Concept', shareUrl: undefined, lastReminderAt: null };
      const next = [item, ...(archive||[])]; setArchive(next);
      await AsyncStorage.setItem(STORAGE.archive, JSON.stringify(next));
    }
  }

  async function updateStatus(id, status){
    if (!DOC_STATUS.includes(status)) return;
    if (supabase && user?.id) { await supabase.from('documents').update({ status }).eq('id', id); await refreshArchive(user.id); }
    else { const next = archive.map(d=> d.id===id ? { ...d, status } : d); setArchive(next); await AsyncStorage.setItem(STORAGE.archive, JSON.stringify(next)); }
  }

  async function updateStatusByNumber(number, status, shareUrl, at){
    if (!number) return; const now = at || new Date().toISOString();
    try {
      if (supabase && user?.id) {
        const patch = { status }; if (shareUrl) patch.share_url = shareUrl; if (status==='Verzonden') patch.sent_at = now;
        supabase.from('documents').update(patch).eq('number', number).eq('user_id', user.id)
          .then(()=> refreshArchive(user.id))
          .catch(e=> console.log('supabase update error', e));
      } else {
        const next = archive.map(d=> d.number===number ? { ...d, status: status||d.status, shareUrl: shareUrl??d.shareUrl, sentAt: status==='Verzonden' ? now : d.sentAt } : d);
        setArchive(next); await AsyncStorage.setItem(STORAGE.archive, JSON.stringify(next));
      }
    } catch(e){ console.log('updateStatusByNumber error', e); }
  }

  return (
    <OffertoContext.Provider value={{
      booting, user,
      company, setCompany,
      klant, setKlant,
      onderdelen, addOnderdeel, removeOnderdeel,
      totals, docType, setDocType, docNummer, setDocNummer, docDatum, setDocDatum,
      signRequested, setSignRequested,
      archive, saveToArchive, updateStatus, updateStatusByNumber,
      signUp, signIn, signOutAll,
      regenerateNumberFor,
      statusFilter, setStatusFilter,
      reminderPrefs, setReminderPrefs,
    }}>
      {children}
    </OffertoContext.Provider>
  );
}
