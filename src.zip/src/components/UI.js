import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Keyboard } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export const Label=({children})=>(<Text style={{fontSize:13,fontWeight:'600',marginBottom:4}}>{children}</Text>);
export const Field=({label,children})=>(<View style={{marginBottom:12}}>{label?<Label>{label}</Label>:null}{children}</View>);
export const TextBox=({value,onChangeText,placeholder,keyboardType='default',editable=true})=> (
  <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} keyboardType={keyboardType} editable={editable} style={{borderWidth:1,borderColor:'#CBD5E1',borderRadius:8,padding:10,fontSize:15,backgroundColor:editable?'white':'#F1F5F9'}}/>
);
export const Button=({title,onPress,variant='primary'})=>{ const bg=variant==='primary'?'#0EA5E9':variant==='danger'?'#EF4444':'#E2E8F0'; const color=variant==='primary'?'#fff':variant==='danger'?'#fff':'#0F172A'; return (<TouchableOpacity onPress={onPress} style={{backgroundColor:bg,padding:12,borderRadius:10,marginVertical:4}}><Text style={{color, fontWeight:'700',textAlign:'center'}}>{title}</Text></TouchableOpacity>); };
export const Card=({children})=>(<View style={{backgroundColor:'white',padding:14,borderRadius:12,marginBottom:10,borderWidth:1,borderColor:'#E2E8F0'}}>{children}</View>);
export const Row=({left,right})=>(<View style={{flexDirection:'row',justifyContent:'space-between',marginVertical:2}}><Text>{left}</Text><Text style={{fontWeight:'700'}}>{right}</Text></View>);

export function Checkbox({checked,onToggle,label}){
  return (
    <TouchableOpacity onPress={onToggle} style={{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:6}}>
      <View style={{width:20,height:20,borderWidth:1,borderColor:'#0EA5E9',borderRadius:4,alignItems:'center',justifyContent:'center',backgroundColor:checked?'#0EA5E9':'white'}}>
        {checked ? <Text style={{color:'white',fontWeight:'900'}}>✓</Text> : null}
      </View>
      {label? <Text>{label}</Text> : null}
    </TouchableOpacity>
  );
}

export function useKeyboardInset(){
  const [bottom,setBottom]=useState(0);
  useEffect(()=>{
    const show = Keyboard.addListener('keyboardDidShow', e=>{ setBottom(e.endCoordinates?.height||0); });
    const hide = Keyboard.addListener('keyboardDidHide', ()=>setBottom(0));
    return ()=>{ show.remove(); hide.remove(); };
  },[]);
  return bottom;
}

export function ScreenWrapper({children}){
  const kb = useKeyboardInset();
  return (
    <SafeAreaView style={{flex:1,backgroundColor:'#F8FAFC'}}>
      <View style={{flex:1,padding:16,paddingBottom:16+kb}}>
        {children}
      </View>
    </SafeAreaView>
  );
}

export const pickerStyles={
  inputIOS:{fontSize:16,padding:10,borderWidth:1,borderColor:'#CBD5E1',borderRadius:8,backgroundColor:'white'},
  inputAndroid:{fontSize:16,padding:10,borderWidth:1,borderColor:'#CBD5E1',borderRadius:8,backgroundColor:'white'},
  placeholder:{color:'#94A3B8'}
};
