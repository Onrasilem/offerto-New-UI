import React from 'react';
import { ScreenWrapper, Card, Field, TextBox, Button } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';

export default function KlantScreen({navigation}){
  const { klant, setKlant } = useOfferto();
  const update = (p)=>setKlant({...klant,...p});
  return (
    <ScreenWrapper>
      <Card>
        <Field label="Bedrijfsnaam"><TextBox value={klant.bedrijfsnaam} onChangeText={v=>update({bedrijfsnaam:v})}/></Field>
        <Field label="Contactpersoon"><TextBox value={klant.contactpersoon} onChangeText={v=>update({contactpersoon:v})}/></Field>
        <Field label="E-mail"><TextBox value={klant.email} onChangeText={v=>update({email:v})}/></Field>
        <Field label="Telefoon"><TextBox value={klant.telefoon} onChangeText={v=>update({telefoon:v})}/></Field>
        <Field label="Adres"><TextBox value={klant.adres} onChangeText={v=>update({adres:v})}/></Field>
        <Field label="BTW-nummer"><TextBox value={klant.btwNummer} onChangeText={v=>update({btwNummer:v})}/></Field>
        <Button title="Volgende: Onderdelen" onPress={()=>navigation.navigate('Onderdelen')}/>
      </Card>
    </ScreenWrapper>
  );
}
