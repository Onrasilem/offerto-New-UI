import React, { useEffect, useState } from 'react';
import { Alert, Modal, Text, View } from 'react-native';
import * as MailComposer from 'expo-mail-composer';
import { ScreenWrapper, Card, Row, Button, Checkbox } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';
import { currency, addDaysISO } from '../../lib/utils';
import { buildPdf, sharePdf } from '../../lib/pdf';

export default function OverzichtScreen(){
  const { company, klant, totals, docType, setDocType, docNummer, docDatum, saveToArchive, signRequested, setSignRequested, regenerateNumberFor, updateStatusByNumber } = useOfferto();
  const { lines, exTotal, btwTotal, incTotal } = totals;
  const [shareModal, setShareModal] = useState({ open:false, url:'' });

  useEffect(()=>{(async()=>{ if(!docNummer){ await regenerateNumberFor(docType); } })()},[]);
  const onSwitchType = async (t)=>{ setDocType(t); await regenerateNumberFor(t); };

  const genPDF = async () => {
    const target = await buildPdf({ company, klant, lines, exTotal, btwTotal, incTotal, docType, nummer: docNummer||'DOC-0000', docDatum });
    await sharePdf(target);
  };

  const emailPDF = async ()=>{
    const target = await buildPdf({ company, klant, lines, exTotal, btwTotal, incTotal, docType, nummer: docNummer||'DOC-0000', docDatum });
    try {
      const avail = await MailComposer.isAvailableAsync();
      if (!avail) { await updateStatusByNumber(docNummer, 'Verzonden'); Alert.alert('E-mail', 'Niet beschikbaar in web. Test op toestel.'); return; }
      await MailComposer.composeAsync({ recipients: [klant.email||''], subject: `${docType} ${docNummer}`, body: `Geachte,\n\nIn bijlage vindt u de ${docType.toLowerCase()}.\n\nMet vriendelijke groet,\n${company.bedrijfsnaam||''}`, attachments: [target] });
      await updateStatusByNumber(docNummer, 'Verzonden');
    } catch (e) { Alert.alert('E-mail', e.message||'Mislukt'); }
  };

  const save = async()=>{ const payload = { type: docType, number: docNummer, date: docDatum, totals: { exTotal, btwTotal, incTotal }, klantSnapshot: { ...klant }, lines, signRequested }; await saveToArchive(payload); };

  return (
    <ScreenWrapper>
      <Card>
        <Row left="Type" right={docType} />
        <View style={{flexDirection:'row',gap:8,marginTop:8}}>
          <View style={{flex:1}}><Button title="OFFERTE" onPress={()=>onSwitchType('OFFERTE')}/></View>
          <View style={{flex:1}}><Button title="FACTUUR" onPress={()=>onSwitchType('FACTUUR')}/></View>
        </View>
        <Row left="Nummer" right={docNummer||'—'} />
        <Row left="Datum" right={docDatum} />
        {docType==='OFFERTE' ? (<Row left="Geldig tot" right={addDaysISO(docDatum, company.offerteGeldigheidDagen || 30)} />) : null}
        <Checkbox checked={signRequested} onToggle={()=>setSignRequested(!signRequested)} label="Indien gewenst digitaal tekenen" />
      </Card>

      <Card>
        {lines.length===0? <Text>Geen onderdelen.</Text> : lines.map((r)=> (
          <View key={r.id} style={{borderTopWidth:1,borderTopColor:'#E2E8F0',paddingVertical:6}}>
            <Text style={{fontWeight:'600'}}>{r.omschrijving}</Text>
            <Text>{r.aantal} × {currency(r.eenheidsprijs)} — Excl. {currency(r.ex)} — BTW {r.btwPerc}% ({currency(r.btwA)}) — Incl. {currency(r.inc)}</Text>
          </View>
        ))}
        {company.voorwaarden ? (
          <View style={{marginTop:10}}>
            <Text style={{fontWeight:'700'}}>Opmerkingen / Voorwaarden</Text>
            <Text style={{color:'#334155'}}>{company.voorwaarden}</Text>
          </View>
        ) : null}
      </Card>

      <Card>
        <Row left="Totaal excl." right={currency(exTotal)} />
        <Row left="BTW" right={currency(btwTotal)} />
        <Row left="Totaal incl." right={currency(incTotal)} />
        <View style={{flexDirection:'row',gap:8,marginTop:10}}>
          <View style={{flex:1}}><Button title="Opslaan in archief" onPress={save}/></View>
          <View style={{flex:1}}><Button title="Genereer PDF" onPress={genPDF}/></View>
        </View>
        <View style={{flexDirection:'row',gap:8,marginTop:6}}>
          <View style={{flex:1}}><Button title="Verstuur per e-mail" variant="secondary" onPress={emailPDF}/></View>
        </View>
      </Card>

      <Modal visible={false} transparent animationType="fade"/>
    </ScreenWrapper>
  );
}
