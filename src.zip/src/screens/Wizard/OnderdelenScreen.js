import React, { useState } from 'react';
import RNPickerSelect from 'react-native-picker-select';
import { ScreenWrapper, Card, Field, TextBox, Button, pickerStyles } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';
import { View, Text } from 'react-native';

const BTW_OPTIONS = [
  { label: '0% (vrijgesteld)', value: 0 },
  { label: '6%', value: 6 },
  { label: '12%', value: 12 },
  { label: '21%', value: 21 },
];
const EENHEID_OPTIONS = [
  { label: 'Stuk', value: 'stuk' },
  { label: 'Uur', value: 'uur' },
  { label: 'm²', value: 'm2' },
  { label: 'm³', value: 'm3' },
  { label: 'Lopende meter', value: 'lm' },
  { label: 'Forfait', value: 'forfait' },
];

const parseNum = (v) => { const n = parseFloat(String(v ?? '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };

export default function OnderdelenScreen({navigation}){
  const { klant, addOnderdeel, onderdelen, removeOnderdeel } = useOfferto();
  const [form,setForm]=useState({omschrijving:'',aantal:'1',eenheid:'stuk',eenheidsprijs:'',btwPerc:klant.btwTariefDefault});
  const isForfait=form.eenheid==='forfait';
  const add = ()=>{
    if(!form.omschrijving) return alert('Vul een omschrijving in.');
    if(!form.eenheidsprijs) return alert('Vul een eenheidsprijs in.');
    const payload={ ...form, aantal: isForfait?1:parseNum(form.aantal), eenheidsprijs: parseNum(form.eenheidsprijs), btwPerc: parseNum(form.btwPerc) };
    addOnderdeel(payload);
    setForm({omschrijving:'',aantal:'1',eenheid:'stuk',eenheidsprijs:'',btwPerc:klant.btwTariefDefault});
  };
  return (
    <ScreenWrapper>
      <Card>
        <Field label={isForfait? 'Aantal (Forfait = 1)' : 'Aantal'}>
          <TextBox value={String(isForfait?1:form.aantal)} onChangeText={v=>setForm({...form,aantal:v})} editable={!isForfait} keyboardType="decimal-pad"/>
        </Field>
        <Field label="Eenheid">
          <RNPickerSelect onValueChange={v=>setForm({...form,eenheid:v})} value={form.eenheid} items={EENHEID_OPTIONS} style={pickerStyles}/>
        </Field>
        <Field label="Omschrijving"><TextBox value={form.omschrijving} onChangeText={v=>setForm({...form,omschrijving:v})}/></Field>
        <Field label="Eenheidsprijs (excl.)"><TextBox value={String(form.eenheidsprijs)} onChangeText={v=>setForm({...form,eenheidsprijs:v})} keyboardType="decimal-pad"/></Field>
        <Field label="BTW%">
          <RNPickerSelect onValueChange={v => setForm({ ...form, btwPerc: Number(v) })} value={Number(form.btwPerc)} items={BTW_OPTIONS} style={pickerStyles} />
        </Field>
        <Button title="Toevoegen" onPress={add}/>
      </Card>

      <Card>
        <Text style={{fontWeight:'700',marginBottom:6}}>Reeds toegevoegd</Text>
        {onderdelen.length===0 ? <Text style={{color:'#64748B'}}>Nog geen onderdelen.</Text> : onderdelen.map(r=> (
          <View key={r.id} style={{borderTopWidth:1,borderTopColor:'#E2E8F0',paddingVertical:8}}>
            <Text style={{fontWeight:'600'}}>{r.omschrijving}</Text>
            <Text>{r.aantal} × € {Number(r.eenheidsprijs).toFixed(2)} ({r.eenheid}) — BTW {r.btwPerc}%</Text>
            <View style={{flexDirection:'row',gap:8,marginTop:6}}>
              <Button title="Verwijder" variant="danger" onPress={()=>removeOnderdeel(r.id)}/>
            </View>
          </View>
        ))}
      </Card>

      <Button title="Volgende: Overzicht & PDF" onPress={()=>navigation.navigate('Overzicht')}/>
    </ScreenWrapper>
  );
}
