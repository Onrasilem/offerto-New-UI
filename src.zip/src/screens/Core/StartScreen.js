import React from 'react';
import { ScreenWrapper, Card, Button } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';

export default function StartScreen({navigation}){
  const { user } = useOfferto();
  return (
    <ScreenWrapper>
      <Card>
        <Button title="Maak offerte" onPress={()=>navigation.navigate('Wizard')}/>
        <Button title="Archief" variant="secondary" onPress={()=>navigation.navigate('Archief')}/>
        <Button title="Instellingen" variant="secondary" onPress={()=>navigation.navigate('Instellingen')}/>
      </Card>
    </ScreenWrapper>
  );
}
