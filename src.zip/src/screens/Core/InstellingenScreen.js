import React from 'react';
import { TextInput, View } from 'react-native';
import { ScreenWrapper, Card, Field, TextBox, Button } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';

export default function InstellingenScreen(){
  const { company, setCompany, signOutAll, reminderPrefs, setReminderPrefs } = useOfferto();
  const update=(p)=>setCompany({...company,...p});
  return (
    <ScreenWrapper>
      <Card>
        <Field label="Bedrijfsnaam"><TextBox value={company.bedrijfsnaam} onChangeText={v=>update({bedrijfsnaam:v})}/></Field>
        <Field label="Adres"><TextBox value={company.adres} onChangeText={v=>update({adres:v})}/></Field>
        <Field label="BTW-nummer"><TextBox value={company.btwNummer} onChangeText={v=>update({btwNummer:v})}/></Field>
        <Field label="E-mail"><TextBox value={company.email} onChangeText={v=>update({email:v})}/></Field>
        <Field label="Telefoon"><TextBox value={company.telefoon} onChangeText={v=>update({telefoon:v})}/></Field>
        <Field label="IBAN"><TextBox value={company.iban} onChangeText={v=>update({iban:v})}/></Field>
        <Field label="BIC"><TextBox value={company.bic} onChangeText={v=>update({bic:v})}/></Field>
        <Field label="Betalingstermijn"><TextBox value={company.betalingsTermijn} onChangeText={v=>update({betalingsTermijn:v})}/></Field>
        <Field label="Logo URL (optioneel)"><TextBox value={company.logoUrl} onChangeText={v=>update({logoUrl:v})} placeholder="https://..."/></Field>
        <Field label="Offerte geldigheid (dagen)"><TextBox value={String(company.offerteGeldigheidDagen)} onChangeText={v=>update({offerteGeldigheidDagen: v})} keyboardType="number-pad"/></Field>
        <Field label="Opmerkingen / Voorwaarden">
          <TextInput multiline value={company.voorwaarden} onChangeText={v=>update({voorwaarden:v})} placeholder="Algemene voorwaarden of opmerkingen" style={{borderWidth:1,borderColor:'#CBD5E1',borderRadius:8,padding:10,minHeight:90,textAlignVertical:'top',backgroundColor:'white'}}/>
        </Field>
      </Card>
      <Card>
        <Field label="Herinnering voorstellen na X dagen (offertes)"><TextBox value={String(reminderPrefs.daysUntilReminder)} onChangeText={v=>setReminderPrefs({ daysUntilReminder: Number(v)||7 })} keyboardType="number-pad"/></Field>
      </Card>
      <Card>
        <Button title="Uitloggen" variant="danger" onPress={async()=>{ await signOutAll(); alert('Uitgelogd'); }}/>
      </Card>
    </ScreenWrapper>
  );
}
