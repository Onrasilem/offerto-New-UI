import React from 'react';
import { View, Text } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';
import { ScreenWrapper, Card, Button, pickerStyles } from '../../components/UI';
import { useOfferto, DOC_STATUS } from '../../context/OffertoContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ArchiefScreen(){
  const { archive, updateStatus, statusFilter, setStatusFilter, company } = useOfferto();
  const filtered = statusFilter==='ALLE' ? archive : archive.filter(d=> (d.status||'Concept')===statusFilter);
  return (
    <ScreenWrapper>
      <Card>
        <Text style={{fontWeight:'700',marginBottom:6}}>Filter op status</Text>
        <RNPickerSelect onValueChange={(v)=>setStatusFilter(v)} value={statusFilter} items={[{label:'Alle',value:'ALLE'}, ...DOC_STATUS.map(s=>({label:s, value:s}))]} style={pickerStyles} />
      </Card>
      <Card>
        {filtered.length===0 ? (
          <Text style={{color:'#64748B'}}>Geen documenten.</Text>
        ) : (
          filtered.map(item=> (
            <View key={item.id} style={{borderTopWidth:1,borderTopColor:'#E2E8F0',paddingVertical:8}}>
              {(() => { try { if (item.type==='OFFERTE') { const dt = new Date(item.date); const until = new Date(dt); until.setDate(until.getDate() + Number(company.offerteGeldigheidDagen||30)); const expired = new Date() > until; return <Text style={{color: expired?'#b91c1c':'#0f172a'}}>{`Geldig tot: ${until.toISOString().slice(0,10)}${expired?' — (VERVALT/VERVALLEN)':''}`}</Text>; } } catch {} return null; })()}
              <Text style={{fontWeight:'600'}}>{item.type} {item.number} — {item.date}</Text>
              <Text>Totaal: € {Number(item.total||0).toFixed(2)} — Status: {item.status||'Concept'}{item.signRequested? ' — digitaal tekenen: ja':''}</Text>
              {item.shareUrl ? (<View style={{marginTop:4}}><Text selectable style={{color:'#0f172a'}}>Link: {item.shareUrl}</Text></View>) : null}
              <View style={{flexDirection:'row',gap:6,marginTop:6,flexWrap:'wrap'}}>
                {DOC_STATUS.filter(s=>s!== (item.status||'Concept')).map(s=> (
                  <View key={s} style={{flexBasis:'48%'}}>
                    <Button title={`Markeer ${s}`} variant="secondary" onPress={()=>updateStatus(item.id, s)} />
                  </View>
                ))}
              </View>
            </View>
          ))
        )}
      </Card>
    </ScreenWrapper>
  );
}
