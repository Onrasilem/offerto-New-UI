import React from 'react';
import { Alert, View, TextInput } from 'react-native';
import { ScreenWrapper, Card, Field, TextBox, Button } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';

export default function ProfielWizard({navigation}){
  const { company, setCompany } = useOfferto();
  const update = (p)=>setCompany({...company,...p});
  const complete = ()=>{ if(!company.bedrijfsnaam || !company.adres || !company.btwNummer){ return Alert.alert('Profiel','Vul bedrijfsnaam, adres en BTW-nummer in.'); } navigation.replace('Start'); };
  return (
    <ScreenWrapper>
      <Card>
        <Field label="Bedrijfsnaam"><TextBox value={company.bedrijfsnaam} onChangeText={v=>update({bedrijfsnaam:v})}/></Field>
        <Field label="Adres"><TextBox value={company.adres} onChangeText={v=>update({adres:v})}/></Field>
        <View style={{flexDirection:'row',gap:10}}>
          <View style={{flex:1}}><Field label="Postcode"><TextBox value={company.postcode} onChangeText={v=>update({postcode:v})}/></Field></View>
          <View style={{flex:2}}><Field label="Stad"><TextBox value={company.stad} onChangeText={v=>update({stad:v})}/></Field></View>
        </View>
        <Field label="Land"><TextBox value={company.land} onChangeText={v=>update({land:v})}/></Field>
        <Field label="BTW-nummer"><TextBox value={company.btwNummer} onChangeText={v=>update({btwNummer:v})}/></Field>
        <View style={{flexDirection:'row',gap:10}}>
          <View style={{flex:1}}><Field label="E-mail"><TextBox value={company.email} onChangeText={v=>update({email:v})}/></Field></View>
          <View style={{flex:1}}><Field label="Telefoon"><TextBox value={company.telefoon} onChangeText={v=>update({telefoon:v})}/></Field></View>
        </View>
        <Field label="Bank"><TextBox value={company.bank} onChangeText={v=>update({bank:v})}/></Field>
        <View style={{flexDirection:'row',gap:10}}>
          <View style={{flex:1}}><Field label="IBAN"><TextBox value={company.iban} onChangeText={v=>update({iban:v})}/></Field></View>
          <View style={{flex:1}}><Field label="BIC"><TextBox value={company.bic} onChangeText={v=>update({bic:v})}/></Field></View>
        </View>
        <Field label="Betalingstermijn"><TextBox value={company.betalingsTermijn} onChangeText={v=>update({betalingsTermijn:v})}/></Field>
        <Field label="Logo URL (optioneel)"><TextBox value={company.logoUrl} onChangeText={v=>update({logoUrl:v})} placeholder="https://..."/></Field>
        <Field label="Offerte geldigheid (dagen)"><TextBox value={String(company.offerteGeldigheidDagen)} onChangeText={v=>update({offerteGeldigheidDagen: v})} keyboardType="number-pad"/></Field>
        <Field label="Opmerkingen / Voorwaarden">
          <TextInput multiline value={company.voorwaarden} onChangeText={v=>update({voorwaarden:v})} placeholder="Algemene voorwaarden of opmerkingen" style={{borderWidth:1,borderColor:'#CBD5E1',borderRadius:8,padding:10,minHeight:90,textAlignVertical:'top',backgroundColor:'white'}}/>
        </Field>
        <Button title="Opslaan en verder" onPress={complete}/>
      </Card>
    </ScreenWrapper>
  );
}
