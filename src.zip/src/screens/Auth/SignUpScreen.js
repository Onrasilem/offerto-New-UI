import React, { useState } from 'react';
import { Alert } from 'react-native';
import { ScreenWrapper, Card, Field, TextBox, Button } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';

export default function SignUpScreen({navigation}){
  const { signUp, company } = useOfferto();
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const submit=async()=>{ try{ if(!email) return Alert.alert('Account','Vul uw e-mail in.'); await signUp(email, password||'changeme', name); if(!company.bedrijfsnaam){ navigation.replace('ProfielWizard'); } else { navigation.replace('Start'); } }catch(e){ Alert.alert('Sign-up', e.message||'Mislukt'); } };
  return (
    <ScreenWrapper>
      <Card>
        <Field label="Naam"><TextBox value={name} onChangeText={setName} placeholder="Uw naam"/></Field>
        <Field label="E-mail"><TextBox value={email} onChangeText={setEmail} placeholder="u@bedrijf.be" keyboardType="email-address"/></Field>
        <Field label="Wachtwoord"><TextBox value={password} onChangeText={setPassword} placeholder="••••••••"/></Field>
        <Button title="Account aanmaken" onPress={submit}/>
        <Button title="Ik heb al een account" variant="secondary" onPress={()=>navigation.replace('Login')}/>
      </Card>
    </ScreenWrapper>
  );
}
