import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Text } from 'react-native';
import { ScreenWrapper, Card, Field, TextBox, Button } from '../../components/UI';
import { useOfferto } from '../../context/OffertoContext';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function LoginScreen({navigation}){
  const { booting, user, signIn, company } = useOfferto();
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  useEffect(()=>{ if(!booting && user){ navigation.replace('Start'); } },[booting,user]);
  if(booting) return <SafeAreaView style={{flex:1,justifyContent:'center',alignItems:'center'}}><ActivityIndicator/><Text>Laden…</Text></SafeAreaView>;
  const doLogin=async()=>{ try{ if(!email) return Alert.alert('Inloggen','Vul uw e-mail in.'); await signIn(email, password||'changeme'); if(!company.bedrijfsnaam){ navigation.replace('ProfielWizard'); } else { navigation.replace('Start'); } }catch(e){ Alert.alert('Login', e.message||'Mislukt'); } };
  return (
    <ScreenWrapper>
      <Card>
        <Field label="E-mail"><TextBox value={email} onChangeText={setEmail} placeholder="u@bedrijf.be" keyboardType="email-address"/></Field>
        <Field label="Wachtwoord"><TextBox value={password} onChangeText={setPassword} placeholder="••••••••"/></Field>
        <Button title="Inloggen" onPress={doLogin}/>
        <Button title="Nieuw hier? Maak een account" variant="secondary" onPress={()=>navigation.replace('SignUp')}/>
      </Card>
    </ScreenWrapper>
  );
}
